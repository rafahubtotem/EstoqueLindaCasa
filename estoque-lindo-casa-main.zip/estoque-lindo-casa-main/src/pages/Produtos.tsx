import { AppLayout } from "@/components/layout/AppLayout";
import { ProductList } from "@/components/inventory/ProductList";
import { AddProductDialog } from "@/components/inventory/AddProductDialog";

const Produtos = () => {
  return (
    <AppLayout>
      <div className="container py-6 space-y-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold">Produtos</h1>
            <p className="text-muted-foreground">Gerenciamento de produtos</p>
          </div>
          <AddProductDialog />
        </div>
        <ProductList />
      </div>
    </AppLayout>
  );
};

export default Produtos;
