export type ProductStatus = "Disponível" | "Vendido" | "Pedido" | "Reservado";
export type StoreUnit = "Shopping Praça Nova" | "Camobi" | "Estoque";
export type ProductCategory = "Sofá" | "Poltrona" | "Cadeira" | "Banqueta" | "Mesa" | "Outros";
export type Manufacturer = "DALLA COSTA" | "Artesano" | "Arte+" | "Fabricante 2" | "Fabricante 3" | "Fabricante 4" | "Fabricante X" | "Fabricante Z";

export const MANUFACTURERS: Manufacturer[] = ["DALLA COSTA", "Artesano", "Arte+", "Fabricante 2", "Fabricante 3", "Fabricante 4", "Fabricante X", "Fabricante Z"];
export type SystemUser = "ANA" | "ALESSANDRA" | "DEISE" | "EDUARDA" | "JOHNATTAN" | "JULIANO" | "LARISSA" | "LUCAS" | "LUIZA" | "RODOLFO" | "ROMUALDO" | "VITOR" | "ADMIN";

export const SYSTEM_USERS: SystemUser[] = ["ANA", "ALESSANDRA", "DEISE", "EDUARDA", "JOHNATTAN", "JULIANO", "LARISSA", "LUCAS", "LUIZA", "RODOLFO", "ROMUALDO", "VITOR"];
export const SALES_USERS: SystemUser[] = ["ANA", "ALESSANDRA", "DEISE", "EDUARDA", "JULIANO", "LARISSA", "LUIZA", "RODOLFO", "ROMUALDO"];
export const ADMIN_USERS: SystemUser[] = ["ADMIN"];

export interface SofaDetails {
  size: string; // em metros
  fabric: string;
  manufacturer: string;
  seats: number;
}
export interface OrderDetails {
  orderDate: string; // ISO format - data que foi feito o pedido
  expectedDate: string; // ISO format - data esperada de chegada
}


export interface HistoryEntry {
  id: string;
  action: "CREATED" | "STATUS_CHANGED" | "TRANSFERRED" | "EDITED" | "SOLD";
  user: SystemUser;
  timestamp: string; // ISO format
  details?: {
    oldStatus?: ProductStatus;
    newStatus?: ProductStatus;
    oldUnit?: StoreUnit;
    newUnit?: StoreUnit;
    reason?: string;
  };
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  category: ProductCategory;
  status: ProductStatus;
  unit: StoreUnit;
  color: string;
  description: string;
  imageUrl?: string;
  images?: string[]; // Array de imagens em base64
  manufacturer: Manufacturer;
  createdAt: string;
  createdBy: SystemUser; // Novo campo
  updatedAt: string;
  soldBy?: string;
  soldAt?: string;
  soldUnit?: string;
  history: HistoryEntry[]; // Histórico completo
  // Campos específicos por categoria
  sofaDetails?: SofaDetails;
  orderDetails?: OrderDetails; // Informações de pedido para fábrica
}
